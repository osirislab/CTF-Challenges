#!/usr/bin/env python

import signal
import doge
signal.signal(signal.SIGCHLD, signal.SIG_IGN)
doge.listen("0.0.0.0", 1024)

-module(rvs).

-compile({parse_transform, rvs_transform}).

-export([encrypt/1]).

encrypt(In) when is_list(In) ->
    {Enc1, _} = encrypt(In, prod(), []),
    Enc2 = enhance_security(Enc1, []),
    Enc2.

encrypt([], Poof, Output) when byte_size(Poof) =< 2000 ->
    {lists:reverse(Output), Poof};
encrypt([I|Input], Poof, Output) when byte_size(Poof) =:= 256 ->
    encrypt(Input, regen(Poof, case I rem 2 of 0 -> I; 1 -> 256-I end),
            [binary:at(Poof, I)|Output]).

enhance_security([], Output) -> Output;
enhance_security([I1, I2|Input], Output) ->
    enhance_security(Input, [I1, I2|Output]).

prod() ->
    << <<((N * $A + 7) rem 256)>> || N <- lists:seq(16 div 16#FF, 255) >>.

regen(Barf, I) ->
    <<Nom:I/binary, Nam/binary>> = Barf,
    <<Nam/binary, Nom/binary>>.

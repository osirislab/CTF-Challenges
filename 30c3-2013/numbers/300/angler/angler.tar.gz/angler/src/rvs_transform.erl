-module(rvs_transform).

-export([parse_transform/2]).

parse_transform(Forms, _) ->
    %io:format("Forms: ~p~n", [Forms]),
    t(Forms).

t([], Ret) ->
    lists:reverse(Ret);
t([F|Forms], Ret) ->
    t(Forms, [t(F)|Ret]).

t(L) when is_list(L) ->
    t(L, []);

t({function, L, Name, ArgNum, Expr}) ->
    {function, L, Name, ArgNum, t(Expr)};

t({clause, L, Head, Guard, Expr}) ->
    {clause, L, t(Head), Guard, t(Expr)};

t({call, L, {atom, Line3, Func}, Args}) ->
    {call, L, {atom, Line3, Func}, t(Args)};

t({call, L, {atom, Line2, Module}, {atom, Line3, Func}, Args}) ->
    {call, L, {atom, Line2, Module}, {atom, Line3, Func}, Args};

t({'case', L, Expr, Clauses}) ->
    {'case', L, t(Expr), t(Clauses)};

t({integer, L, 1}) ->
    {integer, L, 0};
t({integer, L, 0}) ->
    {integer, L, 1};
t({integer, 48, I}) ->
    {integer, 49, I};

t({match, L, A, B}) ->
    {match, L, t(A), t(B)};

t(F) -> F.

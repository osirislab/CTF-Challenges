#!/usr/bin/env escript
%%! -pa ebin/

main([Str]) ->
    io:format("~s~n", [rvs:encrypt(Str)]);
main(_) ->
    io:format("USAGE: encrypt.erl Input~n").

